import 'package:flutter/material.dart';

void main() {
  runApp(MyTycoonGame());
}

class MyTycoonGame extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tycoon Oyunu',
      theme: ThemeData(primarySwatch: Colors.green),
      home: TycoonHomePage(),
    );
  }
}

class TycoonHomePage extends StatefulWidget {
  @override
  _TycoonHomePageState createState() => _TycoonHomePageState();
}

class _TycoonHomePageState extends State<TycoonHomePage> {
  int money = 0;
  int income = 1;

  void earnMoney() {
    setState(() {
      money += income;
    });
  }

  void upgrade() {
    if (money >= 50) {
      setState(() {
        money -= 50;
        income += 1;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tycoon Oyunu'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Para: \$${money.toString()}', style: TextStyle(fontSize: 30)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: earnMoney,
              child: Text('Çalış! (+\$${income})'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: upgrade,
              child: Text('Yükseltme Satın Al (50\$)'),
            ),
          ],
        ),
      ),
    );
  }
}import 'dart:async';
import 'package:flutter/material.dart';

void main() {
  runApp(MyTycoonGame());
}

class MyTycoonGame extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'İş Yeri Tycoon',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: TycoonHomePage(),
    );
  }
}

class Business {
  String name;
  int cost;
  int incomePerSecond;
  int count;

  Business({
    required this.name,
    required this.cost,
    required this.incomePerSecond,
    this.count = 0,
  });
}

class TycoonHomePage extends StatefulWidget {
  @override
  _TycoonHomePageState createState() => _TycoonHomePageState();
}

class _TycoonHomePageState extends State<TycoonHomePage> {
  int money = 0;
  late Timer timer;

  List<Business> businesses = [
    Business(name: "Dükkan", cost: 100, incomePerSecond: 5),
    Business(name: "Fabrika", cost: 500, incomePerSecond: 20),
    Business(name: "Teknoloji Şirketi", cost: 1000, incomePerSecond: 50),
  ];

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(Duration(seconds: 1), (_) => generateIncome());
  }

  void generateIncome() {
    int totalIncome = businesses.fold(
      0,
      (sum, b) => sum + (b.count * b.incomePerSecond),
    );

    setState(() {
      money += totalIncome;
    });
  }

  void buyBusiness(int index) {
    Business b = businesses[index];
    if (money >= b.cost) {
      setState(() {
        money -= b.cost;
        b.count += 1;
        b.cost = (b.cost * 1.3).toInt(); // Fiyatı artır
      });
    }
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  Widget buildBusinessCard(int index) {
    Business b = businesses[index];
    return Card(
      child: ListTile(
        title: Text('${b.name} (x${b.count})'),
        subtitle: Text('Gelir: \$${b.incomePerSecond}/s - Fiyat: \$${b.cost}'),
        trailing: ElevatedButton(
          onPressed: () => buyBusiness(index),
          child: Text("Kur"),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('İş Yeri Tycoon'),
      ),
      body: Column(
        children: [
          SizedBox(height: 20),
          Text("Para: \$${money}", style: TextStyle(fontSize: 28)),
          SizedBox(height: 20),
          Expanded(
            child: ListView.builder(
              itemCount: businesses.length,
              itemBuilder: (context, index) {
                return buildBusinessCard(index);
              },
            ),
          ),
        ],
      ),
    );
  }
}